package lk.ijse.CherryClothing.bo;

public interface SuperBO {
}
