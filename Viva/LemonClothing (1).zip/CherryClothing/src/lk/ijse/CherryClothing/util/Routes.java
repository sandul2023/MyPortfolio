package lk.ijse.CherryClothing.util;

public enum Routes {
    LOGIN, CASHIER, CUSTOMER , PLACEORDER , CCLOTHES , EMPLOYEE
}
