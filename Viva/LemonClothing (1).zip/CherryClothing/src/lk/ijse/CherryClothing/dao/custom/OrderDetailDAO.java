package lk.ijse.CherryClothing.dao.custom;

import lk.ijse.CherryClothing.entity.Order;
import lk.ijse.CherryClothing.entity.OrderDetail;

public interface OrderDetailDAO extends CrudDAO<OrderDetail>{
}
