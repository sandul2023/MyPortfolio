package lk.ijse.CherryClothing.dao.custom;

import lk.ijse.CherryClothing.entity.Customer;
import lk.ijse.CherryClothing.entity.Item;

public interface ItemDAO extends CrudDAO<Item>{
}
