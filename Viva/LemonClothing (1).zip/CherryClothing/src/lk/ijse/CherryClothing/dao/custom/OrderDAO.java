package lk.ijse.CherryClothing.dao.custom;

import lk.ijse.CherryClothing.entity.Order;

public interface OrderDAO extends CrudDAO<Order>{
}
