package lk.ijse.CherryClothing.dao.custom;

import lk.ijse.CherryClothing.entity.Employee;

public interface EmployeeDAO extends CrudDAO<Employee>{
}
