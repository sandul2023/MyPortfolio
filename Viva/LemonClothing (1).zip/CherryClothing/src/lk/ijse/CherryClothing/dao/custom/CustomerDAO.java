package lk.ijse.CherryClothing.dao.custom;

import lk.ijse.CherryClothing.entity.Customer;

public interface CustomerDAO extends CrudDAO<Customer>{
}
