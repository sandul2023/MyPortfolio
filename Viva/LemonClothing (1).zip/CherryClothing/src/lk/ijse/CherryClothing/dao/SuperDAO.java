package lk.ijse.CherryClothing.dao;

public interface SuperDAO {
}
